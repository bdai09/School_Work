package com.example.bdai9.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup radioGroup1;
    RadioGroup radioGroup2;
    Button radioButton1;
    Button radioButton2;
    Button colorButton;
    TextView textView1;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //leftside radio group
        radioGroup1 = findViewById(R.id.radiogroup1);
        radioGroup1.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup1, int checkedId) {
                        if (checkedId == R.id.radio1)
                            Toast.makeText(getApplicationContext(), "Alice", Toast.LENGTH_SHORT).show();
                        if (checkedId == R.id.radio2)
                            Toast.makeText(getApplicationContext(), "Bob", Toast.LENGTH_SHORT).show();
                        if (checkedId == R.id.radio3)
                            Toast.makeText(getApplicationContext(), "Carol", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        radioButton1 = findViewById(R.id.buttonleft);
        textView1 = findViewById(R.id.text1);

        radioButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedRadio = radioGroup1.getCheckedRadioButtonId();
                if (selectedRadio == R.id.radio1)
                    textView1.setText("Boujour Alice");
                if (selectedRadio == R.id.radio2)
                    textView1.setText("Boujour Bob");
                if (selectedRadio == R.id.radio3)
                    textView1.setText("Boujour Carol");
            }
        });
        //right side radio group
        radioGroup2 = findViewById(R.id.radiogroup2);
        radioGroup2.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup2, int checkedId) {
                        if (checkedId == R.id.radio4)
                            Toast.makeText(getApplicationContext(), "Dave", Toast.LENGTH_SHORT).show();
                        if (checkedId == R.id.radio5)
                            Toast.makeText(getApplicationContext(), "Eve", Toast.LENGTH_SHORT).show();
                        if (checkedId == R.id.radio6)
                            Toast.makeText(getApplicationContext(), "Fred", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        radioButton2 = findViewById(R.id.buttonright);
        textView2 = findViewById(R.id.text2);

        radioButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedRadio = radioGroup2.getCheckedRadioButtonId();
                if (selectedRadio == R.id.radio4)
                    textView2.setText("Hello Dave");
                if (selectedRadio == R.id.radio5)
                    textView2.setText("Hello Eve");
                if (selectedRadio == R.id.radio6)
                    textView2.setText("Hello Fred");
            }
        });

        //checkbox group
        final CheckBox check1=findViewById(R.id.checkbox1);
        check1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(((CheckBox)view).isChecked())
                    Toast.makeText(getApplicationContext(), "Red", Toast.LENGTH_SHORT).show();
            }
        });

        final CheckBox check2=findViewById(R.id.checkbox2);
        check2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(((CheckBox)view).isChecked())
                    Toast.makeText(getApplicationContext(), "Yellow", Toast.LENGTH_SHORT).show();
            }
        });

        final CheckBox check3=findViewById(R.id.checkbox3);
        check3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(((CheckBox)view).isChecked())
                    Toast.makeText(getApplicationContext(), "Green", Toast.LENGTH_SHORT).show();
            }
        });

        colorButton = findViewById(R.id.button1);
        colorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuffer colors=new StringBuffer();
                if (check1.isChecked())
                    colors.append(" Red");
                if (check2.isChecked())
                    colors.append(" Yellow");
                if (check3.isChecked())
                    colors.append(" Green");
                Toast.makeText(getApplicationContext(), colors, Toast.LENGTH_SHORT).show();
            }
        });

    }
}



