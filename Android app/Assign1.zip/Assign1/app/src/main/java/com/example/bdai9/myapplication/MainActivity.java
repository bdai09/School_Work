package com.example.bdai9.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private RadioGroup radioGroup1;
    private RadioGroup radioGroup2;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private Button btnDisplay1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addListenerOnRadioButton();

    }
    public void addListenerOnRadioButton() {

        radioGroup1 = (RadioGroup) findViewById(R.id.radiogroup1);
        btnDisplay1 = (Button) findViewById(R.id.buttonleft);

        btnDisplay1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // get selected radio button from radioGroup
                int selectedId = radioGroup1.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioButton1 = (RadioButton) findViewById(selectedId);

                TextView textView1=findViewById(R.id.text1);
                textView1.setText("Boujour "+radioButton1.getText().toString());

            }

        });

    }
    public void onRadioButtonClicked(){
        radioGroup1 = (RadioGroup) findViewById(R.id.radiogroup1);
        RadioButton rb = (RadioButton) radioGroup1.findViewById(radioGroup1.getCheckedRadioButtonId());
        Toast.makeText(MainActivity.this, rb.getText(), Toast.LENGTH_SHORT).show();
    }
}



