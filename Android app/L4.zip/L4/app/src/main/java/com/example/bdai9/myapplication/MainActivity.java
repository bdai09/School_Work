package com.example.bdai9.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
  EditText editText1, editText2;
    String[] arrayAlice={"A","B","C","D","E","F","G","H","I","J","K","L","M","N",
        "O","P","Q","R","S","T","U","V","W","X","Y","Z"};
    String[] arrayAlice2=new String[99];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listViewBob=(ListView)findViewById(R.id.list);
        ArrayAdapter<String> adapterAdapterCarol=new ArrayAdapter<String>(this,R.layout.activity_listview,arrayAlice);
        listViewBob.setAdapter(adapterAdapterCarol);


        for(int j=0;j<arrayAlice2.length;j++){
            arrayAlice2[j]=""+(j+1)*7;
        }
        GridView gridViewBob2=(GridView)findViewById(R.id.list2);
        ArrayAdapter<String> adapterAdapterCarol2=new ArrayAdapter<String>(this,R.layout.activity_listview2,arrayAlice2);
        gridViewBob2.setAdapter(adapterAdapterCarol2);


    }
}



