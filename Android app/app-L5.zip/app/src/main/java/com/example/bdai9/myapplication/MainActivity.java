package com.example.bdai9.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editText1, editText2;
    String[] itemnameLeft={"Love Pet1","Love Pet2","Love Pet3","Love Pet4","Love Pet5","Love Pet6","Love Pet7","Love Pet8","Love Pet9","Love Pet10","Love Pet11","Love Pet12"};
    Integer[] imgid1={R.drawable.pic1,R.drawable.pic2,R.drawable.pic3,R.drawable.pic4,R.drawable.pic5,
            R.drawable.pic6,R.drawable.pic7,R.drawable.pic8,R.drawable.pic9,R.drawable.pic10,
            R.drawable.pic11,R.drawable.pic12};

    String[] itemnameRight={"Love Pet13","Love Pet14","Love Pet15","Love Pet16","Love Pet17","Love Pet18","Love Pet19","Love Pet20","Love Pet21","Love Pet22","Love Pet23","Love Pet24"};
    Integer[] imgid2={R.drawable.pic13,R.drawable.pic14,R.drawable.pic15,R.drawable.pic16,R.drawable.pic17,
            R.drawable.pic18,R.drawable.pic19,R.drawable.pic20,R.drawable.pic21,R.drawable.pic22,
            R.drawable.pic23,R.drawable.pic24};
    String[] description2={"A","B","C","D","E","F","G","H","I","J","K","L"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CustomListAdapter adapterPet1=new CustomListAdapter(this,itemnameLeft,imgid1);
        ListView listViewPet1=findViewById(R.id.list);
        listViewPet1.setAdapter(adapterPet1);
        listViewPet1.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView,View view,int i, long l){
                        Intent intent=new Intent(MainActivity.this, detailsActivity.class);
                        intent.putExtra("itemname1",itemnameLeft[i]);
                        intent.putExtra("imgid1",imgid1[i].toString());
                        startActivity(intent);

                    }
                });


        CustomListAdapter2 adapterPet2=new CustomListAdapter2(this,itemnameRight,imgid2,description2 );
        ListView listViewPet2=findViewById(R.id.list2);
        listViewPet2.setAdapter(adapterPet2);
        listViewPet2.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView,View view,int i, long l){
                        Intent intent=new Intent(MainActivity.this, details2Activity.class);
                        intent.putExtra("itemname2",itemnameRight[i]);
                        intent.putExtra("imgid2",imgid2[i].toString());
                        intent.putExtra("desdisplay2",description2[i]);
                        startActivity(intent);
                    }
                });

    }
}

class CustomListAdapter extends ArrayAdapter<String>{

    private Activity context;
    private String[] name1;
    private Integer[] image1;
    CustomListAdapter(Activity context, String[] name2,Integer[] image2){
        super(context, R.layout.activity_listview,name2);
        this.context=context;
        this.name1=name2;
        this.image1=image2;
    }
    public @NonNull
    View getView(int position, View view, @NonNull ViewGroup parent){
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.activity_listview,null,true);
        TextView tvName=rowView.findViewById(R.id.nameID);
        ImageView imageView=rowView.findViewById(R.id.iconID);
        tvName.setText(name1[position]);
        imageView.setImageResource(image1[position]);
        return rowView;
    }

}


class CustomListAdapter2 extends ArrayAdapter<String>{

    private Activity context;
    private String[] name2;
    private Integer[] image2;
    private String[] description2;

    CustomListAdapter2(Activity context, String[] name22,Integer[] image22, String[] description22){
        super(context, R.layout.activity_listview2,name22);
        this.context=context;
        this.name2=name22;
        this.image2=image22;
        this.description2=description22;
    }
    public @NonNull
    View getView(int position, View view, @NonNull ViewGroup parent){
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.activity_listview2,null,true);
        TextView tvName=rowView.findViewById(R.id.nameID2);
        ImageView imageView=rowView.findViewById(R.id.iconID2);
        TextView description=rowView.findViewById(R.id.desdisplay2);

        tvName.setText(name2[position]);
        imageView.setImageResource(image2[position]);
        description.setText(description2[position]);
        return rowView;
    }

}


