package com.example.bdai9.myapplication;

import android.content.Intent;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class details2Activity extends AppCompatActivity {
    ImageView imageView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details2);
        Intent intent=getIntent();

        String string2=intent.getStringExtra("itemname2");
        TextView textView2=findViewById(R.id.nameDisplay2);
        textView2.setText(string2);


        string2=intent.getStringExtra("imgid2");
        Integer imageValue2=new Integer(string2);
        imageView2=findViewById(R.id.iconDisplay2);
        imageView2.setImageResource(imageValue2);

        string2=intent.getStringExtra("desdisplay2");
        TextView textView1=findViewById(R.id.desDisplay2);
        textView1.setText(string2);
    }

}
