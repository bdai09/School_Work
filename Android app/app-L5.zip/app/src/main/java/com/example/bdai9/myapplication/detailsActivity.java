package com.example.bdai9.myapplication;

import android.content.Intent;
import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class detailsActivity extends AppCompatActivity {
    TextView textView1;
    ImageView imageView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Intent intent=getIntent();


        String string1=intent.getStringExtra("imgid1");
        Integer imageValue1=new Integer(string1);
        imageView1=findViewById(R.id.iconDisplay1);
        imageView1.setImageResource(imageValue1);

        string1=intent.getStringExtra("itemname1");
        TextView textView1=findViewById(R.id.nameDisplay1);
        textView1.setText(string1);

    }
}
