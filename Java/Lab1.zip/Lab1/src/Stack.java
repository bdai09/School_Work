import java.util.ArrayList;

public class Stack {
private ArrayList<String> arr=new ArrayList<String>();
public static void 
}
