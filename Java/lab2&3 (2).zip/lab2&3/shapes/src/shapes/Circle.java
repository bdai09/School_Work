package shapes;

public class Circle implements Shape{
	private double r;

	 public Circle() {
		r=0.0;
	}
	 public Circle(double r) throws CircleException {
		 if(r>0) {
			this.r=r;
		 }else {
		 throw new CircleException("Invalid radius!");
		 }
	} 

	 @Override
	 public String toString() {
		 return String.format("Circle {r=%.1f} perimeter = %g", 
				 getterR(),getPerimeter());
	 }
	 @Override
	 public double getPerimeter() {
		 return 2*Math.PI*getterR();
	 }
	 
	 public void setterR(double r) throws CircleException {
		 if(r>0) {
			 this.r=r;
		 }
		 else {
			 throw new CircleException("Invalid radius!");
		 }
	 }
	 
	public double getterR() {
		return r;
	}
}
