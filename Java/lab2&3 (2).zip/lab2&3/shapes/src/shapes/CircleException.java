package shapes;

@SuppressWarnings("serial")
public class CircleException extends Exception {
public CircleException(String message) {
	   super(message);
   }
}
