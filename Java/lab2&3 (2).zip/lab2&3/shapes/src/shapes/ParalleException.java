package shapes;


public class ParalleException extends Exception{
public ParalleException(String message) {
	super(message);
}
}
