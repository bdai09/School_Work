package shapes;

public class Parallelogram implements Shape{
	private double sideA;
	private double sideB;
	
	 public Parallelogram() {
		sideA=0.0;
		sideB=0.0;
	}
	 
	 public Parallelogram(double a, double b) throws ParalleException {
		 if(a>0&&b>0) {
			this.sideA=a;
			this.sideB=b;
		 }else {
			 throw new ParalleException("Invalid side(s)!");
		 }
	} 
	 @Override
	 public String toString() {
		 return String.format("Parallelogram {w=%.1f, h=%.1f} perimeter = %g"
	 ,getterA(),getterB(),getPerimeter());
	 }
	 @Override
	 public double getPerimeter() {
		 return (getterA()+getterB())*2;
	 }
	 
	 public void setterA(double a)throws ParalleException {
		 if(a>0) {
		   this.sideA=a;
		 }
		 else {
			 throw new ParalleException("Invalid side!");
		 }
	 }
	 
	 public void setterB(double b)throws ParalleException {
		 if(b>0) 
		  this.sideB=b;
		 else
			 throw new ParalleException("Invalid side!");		 
	 }
	 
	public double getterA() {
		return sideA;
	}
	
	public double getterB() {
		return sideB;
	}
	
}
