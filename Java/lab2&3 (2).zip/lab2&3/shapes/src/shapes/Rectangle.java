package shapes;

public class Rectangle extends Parallelogram {
	 public Rectangle() {
		super();
	}
	 public Rectangle(double a, double b)throws ParalleException  {
		 super(a,b);
	} 
	 @Override
	 public String toString() {
		 return String.format("Rectangle {w=%.1f, h=%.1f} perimeter = %g", 
				 getterA(),getterB(),getPerimeter());
	 }

}
