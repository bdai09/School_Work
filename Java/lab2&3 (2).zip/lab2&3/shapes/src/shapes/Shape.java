package shapes;

public interface Shape {
    double getPerimeter();
    String toString();
}
