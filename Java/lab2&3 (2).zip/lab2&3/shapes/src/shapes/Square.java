package shapes;

public class Square extends Rectangle {

	 public Square() {
		super();
	}
	 public Square(double a)throws ParalleException {
			super(a,a);

	} 
	 @Override
	 public double getPerimeter() {
		 return getterA()*4;
	 }
	 @Override
	 public String toString() {
		 return String.format("Square {s=%s} perimeter = %g",
				 getterA(),getPerimeter());
	 }
}
