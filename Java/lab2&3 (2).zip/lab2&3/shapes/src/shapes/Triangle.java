package shapes;

public class Triangle implements Shape {
	private double sideA;
	private double sideB;
	private double sideC;
	
	 public Triangle() {
		sideA=0.0;
		sideB=0.0;
		sideC=0.0;
	}
	 
	 public Triangle(double a, double b, double c) throws TriangleException{
		 if(a>0&&b>0&&c>0&&a+b>c&&a+c>b&&b+c>a) {
				this.sideA=a;
				this.sideB=b;
				this.sideC=c;
		 }else {
			 throw new TriangleException("Invalid side(s)!");
		 }
	} 
	 @Override 
	 public String toString() {
		 return String.format("Triangle {s1=%.1f, s2=%.1f, s3=%.1f} perimeter = %g"
	  , getterA(),getterB(),getterC(),getPerimeter());
	 }
	 
	 @Override
	 public double getPerimeter() {
		 return getterA()+getterB()+getterC();
	 }
	 
	 public void setterA(double a)throws TriangleException {
		 if(a>0)
		 this.sideA=a;
		 else
			 throw new TriangleException("Invalid side(s)!");
	 }
	 
	 public void setterB(double b)throws TriangleException {
		 if(b>0)
		  this.sideB=b;
		 else
			 throw new TriangleException("Invalid side(s)!");
	 }
	 
	 public void setterC(double c) throws TriangleException{
		 if(c>0)
		  this.sideC=c;
		 else
			 throw new TriangleException("Invalid side(s)!");
	 }
	 
	public double getterA() {
		return sideA;
	}
	
	public double getterB() {
		return sideB;
	}
	
	public double getterC() {
		return sideC;
	}
}
