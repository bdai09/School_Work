package shapes;

public interface Shape {
    double getPerimeter();
}
