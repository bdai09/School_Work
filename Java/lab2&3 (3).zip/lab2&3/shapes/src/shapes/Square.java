package shapes;

public class Square extends Rectangle {

	 public Square() {
		super();
	}
	 public Square(double a)throws ParalleException {
			super(a,a);

	} 
	 @Override
	 public void setA(double a)throws ParalleException {
		 if(a>0) {
		   setA(a);
		   setB(a);
		 }
		 else {
			 throw new ParalleException("Invalid side!");
		 }
	 }
	 @Override
	 public void setB(double b)throws ParalleException {
		 if(b>0) {
			 setA(b);
		     setB(b);
		 }
		 else
			 throw new ParalleException("Invalid side!");		 
	 } 
	 
	 @Override
	 public double getPerimeter() {
		 return getA()*4;
	 }
	 @Override
	 public String toString() {
		 return String.format("Square {s=%s} perimeter = %g",
				 getA(),getPerimeter());
	 }
}
