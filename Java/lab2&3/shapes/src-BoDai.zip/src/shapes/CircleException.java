//student name: Bo Dai
//student number: 132954173
//workshop:3, June7,2019

package shapes;

@SuppressWarnings("serial")
public class CircleException extends Exception {
public CircleException(String message) {
	   super(message);
   }
}
