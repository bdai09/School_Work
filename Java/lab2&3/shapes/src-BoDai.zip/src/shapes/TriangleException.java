//student name: Bo Dai
//student number: 132954173
//workshop:3, June7,2019

package shapes;

@SuppressWarnings("serial")
public class TriangleException extends Exception {
 public TriangleException(String message) {
	 super(message);
 }
}
