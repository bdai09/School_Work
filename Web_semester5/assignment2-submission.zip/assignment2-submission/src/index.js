/*********************************************************************************
 * WEB422 – Assignment 2
 * I declare that this assignment is my own work in accordance with Seneca Academic Policy.
 * No part of this assignment has been copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Name: ____Bo Dai______ Student ID: _132954173_____ Date: __May30, 2019______
 *
 *
 ********************************************************************************/

// Import jQuery, which will also expose $ on the global `window` Object.
import $ from './jquery-es';
// After jQuery is loaded, we can load the Bootstrap JS, which depends on jQuery.
import 'bootstrap';

// Place your imports for Moment.js and Lodash here...
import moment from 'moment';
import _ from 'lodash';

// The rest of your code can go here.  You're also welcome to split
// your code up into multiple files using ES modules and import/export.
let employeesModel = []; //view model for current "employees" view

//populate the "employeesModel" array, by issuing an AJAX call to Teams API hosted on Heroku
//making a GET request for /employees.
function initializeEmployeesModel() {
  $.ajax({
    url: 'https://agile-river-17555.herokuapp.com/employees',
    type: 'GET',
    contentType: 'application/json'
  })
    .done(function(data) {
      employeesModel = data;
      refreshEmployeeRows(employeesModel);
    })
    .fail(function() {
      showGenericModal('Error', 'Unable to get Employees');
    });
}

function showGenericModal(title, message) {
  $('#genericModal .modal-title')
    .empty()
    .append(title);
  $('#genericModal .modal-body')
    .empty()
    .append(message);
  $('#genericModal').modal('show');
}

function refreshEmployeeRows(employees) {
  $('#employees-table').empty();
  let template = _.template(
    '<% _.forEach(employees,function(employee){%>' +
      '<div class="row body-row" data-id="<%- employee._id %>">' +
      '<div class="col-xs-4 body-column"><%- employee.FirstName %></div>' +
      '<div class="col-xs-4 body-column"><%- employee.LastName %></div>' +
      '<div class="col-xs-4 body-column"><%- employee.Position.PositionName %></div>' +
      '</div>' +
      '<% }); %>'
  );
  $('#employees-table').append(template({ employees: employees }));
}

function getFilteredEmployeesModel(filterString) {
  let target = filterString.toLowerCase();
  let filteredEmployeesModel = _.filter(employeesModel, employee => {
    if (
      employee.FirstName.toLowerCase().search(target) !== -1 ||
      employee.LastName.toLowerCase().search(target) !== -1 ||
      employee.Position.PositionName.toLowerCase().search(target) !== -1
    )
      return true;
    return false;
  });
  return filteredEmployeesModel;
}

function getEmployeeModelById(id) {
  let result = null;
  $.grep(employeesModel, function(employee) {
    if (employee._id === id) result = _.cloneDeep(employee);
  });
  return result;
}

$(function() {
  initializeEmployeesModel();
  $('#employee-search').on('keyup', function() {
    let filtered = getFilteredEmployeesModel(this.value);
    refreshEmployeeRows(filtered);
  });

  $(document.body).on('click', '.body-row', function() {
    let clickEmployee = getEmployeeModelById($(this).attr('data-id'));
    if (clickEmployee !== null) {
      clickEmployee.HireDate = moment(clickEmployee.HireDate).format('LL');
      let temp = _.template(
        '<strong>Address: </strong><%- clickEmployee.AddressStreet %> <%- clickEmployee.AddressCity %>, <%- clickEmployee.AddressState %> <%- clickEmployee.AddressZip %><br>' +
          '<strong>Phone Number: </strong> <%- clickEmployee.PhoneNum %> ext: <%- clickEmployee.Extension %><br>' +
          '<strong>Hire Date: </strong> <%- clickEmployee.HireDate %>'
      );
      //store result
      let clicked = temp({ clickEmployee: clickEmployee });

      showGenericModal(clickEmployee.FirstName + ' ' + clickEmployee.LastName, clicked);
    }
  });
});
