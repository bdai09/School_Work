// Bootstrap expects window.jQuery to exist, so we do that...
import jquery from 'jquery';
window.jQuery = jquery;

export default jquery;
