
## 1. How to run and build this app:

Tool: This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

In the project directory, you can run:

### `npm start`

To create a product, you can run:

### `npm run build`


## 2. Components, libraries, third-party tools in this app:

### `Components`

Navbar.js - used as header to display the theme of page for all routes

Employees.js - render all employees in the API(/employees), return in a table of information format

Projects.js - render all projects data fetched from API(/projects), display in a table format

Teams.js - render all teams data fetched from API(/teams-raw), dispaly in panel format

Teams-raw.js - combine teams-raw data with employees and projects, create MulitSelect dropdown menu with readable names, loop each team and pass team data to <Panel> component 

Panel.js - child component under Teams-raw.js, to put each team information in a Panel card

Team.js - display all infomation for the selected team with route /team/:teamId

### `libraries`

This app uses bootstrap and customized css in App.css file

### `third-party tools`

axios - to get/put data to Teams API

react-select - used for multiple Select component used in Panel.js

toasted-notes - applied for toast popup error message if network request fail



## 3. Extra Notes:

SAVE button in Team Panel is only enabled when data has changed.

After click SAVE button, if update is successful, a message will indicate the user that it works, also the header of that team panel will be changed into yellow.

Used eslint and prettier for clean code
