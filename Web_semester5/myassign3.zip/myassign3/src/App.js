/*********************************************************************************
* WEB422 – Assignment 03
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part
of this
* assignment has been copied manually or electronically from any other source (including web sites)
or
* distributed to other students.
*
* Name: ___Bo Dai___ Student ID: _132954173_____ Date: _Jun18,2019_______
*
********************************************************************************/



import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';
import './App.css';
import Employees from './components/Employees.js';
import Projects from './components/Projects.js';
import Teams from './components/Teams.js';
import Team from './components/Team.js';
import Teamsraw from './components/Teams-raw.js';

class App extends Component {
    render() {
        return (
            <Switch>
                <Route exact path="/" render={() => <Teamsraw />} />

                <Route exact path="/employees" render={() => <Employees />} />

                <Route exact path="/projects" render={() => <Projects />} />

                <Route exact path="/teams" render={() => <Teams />} />

                <Route path="/team/:id" render={props => <Team id={props.match.params.id} />} />

                <Route render={() => <h1>Page Not Found</h1>} />
            </Switch>
        );
    }
}

export default App;
