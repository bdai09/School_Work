import React, { Component } from 'react';
import Navbar from './Navbar';
import axios from 'axios';
import toaster from 'toasted-notes';

class Employees extends Component {
    constructor() {
        super();
        this.state = {
            employees: []
        };
    }

    componentDidMount() {
        axios
            .get('https://agile-river-17555.herokuapp.com/employees')
            .then(res => {
                //const employees=res.data;
                this.setState({
                    employees: res.data
                });
            })
            .catch(() =>
                toaster.notify(
                    'Network Request Error for Employees! Try again or check connection',
                    {
                        duration: 5000
                    }
                )
            );
    }

    render() {
        return (
            <div>
                <Navbar title="Assignment3 - Employees Details"></Navbar>
                <table className="table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>ID</th>
                            <th>Address</th>
                            <th>Phone Number</th>
                            <th>Hire Date</th>
                            <th>Position</th>
                            <th>Salary</th>
                            <th>Salary Bonus</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.employees.map(employee => {
                            return (
                                <tr key={employee._id}>
                                    <td>
                                        <b>{employee.FirstName + ' ' + employee.LastName}</b>
                                    </td>
                                    <td>{employee._id}</td>
                                    <td>
                                        {employee.AddressStreet +
                                            ', ' +
                                            employee.AddressCity +
                                            ', ' +
                                            employee.AddressState +
                                            ' ' +
                                            employee.AddressZip}
                                    </td>
                                    <td>{employee.PhoneNum + ' ext: ' + employee.Extension}</td>
                                    <td>{employee.HireDate}</td>
                                    <td>{employee.Position.PositionName}</td>
                                    <td>{employee.Position.PositionBaseSalary + ' $ '}</td>
                                    <td>{employee.SalaryBonus + ' $ '}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        );
    }
}

export default Employees;
