import React, { Component } from 'react';
import '../../src/App.css';

class Navbar extends Component {
    render() {
        return (
            <nav className="navbar navbar-custom">
                <div className="container-fluid">
                    <div className="navbar-header">
                        <span className="navbar-brand">{this.props.title}</span>
                    </div>
                </div>
            </nav>
        );
    }
}

export default Navbar;
