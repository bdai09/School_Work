import React, { Component } from 'react';
import Select from 'react-select';
import axios from 'axios';
import '../../src/App.css';
import toaster from 'toasted-notes';

class Panel extends Component {
    constructor(props) {
        super(props);
        this.state = {
            changeInfo: false,
            TeamLead: [],
            TeamMembers: [], //members only for this team
            TeamProjects: [], //projects for specific team
            employees: [], //store all employees
            projects: [], //store all projects
            colorChange: false //control header color change if click Save
        };
        this.handleLeadChange = this.handleLeadChange.bind(this);
        this.handleMemChange = this.handleMemChange.bind(this);
        this.handleProChange = this.handleProChange.bind(this);
        this.handleSave = this.handleSave.bind(this);
    }

    componentDidMount() {
        axios
            .get('https://agile-river-17555.herokuapp.com/employees')
            .then(res => {
                const employees = res.data;
                //deal with all employees drop down list
                const storeEmps = employees.map(employee => ({
                    value: employee._id,
                    label: employee.FirstName + ' ' + employee.LastName
                }));

                this.setState({
                    employees: storeEmps
                });

                //deal with selected employees for the team
                let validEmps = this.props.TeamEmps;
                //filter()-creates new array with elements that pass test
                const members = storeEmps.filter(emp =>
                    validEmps.find(empId => empId === emp.value)
                );
                this.setState({
                    TeamMembers: members
                });

                //deal with team lead
                let lead = this.props.TeamLead;
                const leadFull = storeEmps.filter(emp => lead === emp.value);

                this.setState({
                    TeamLead: leadFull
                });
            })
            .catch(() =>
                toaster.notify(
                    'Network Request Error for Employees! Try again or check connection',
                    {
                        duration: 5000
                    }
                )
            );

        //projects:
        axios
            .get('https://agile-river-17555.herokuapp.com/projects')
            .then(res => {
                const projects = res.data;
                let validPros = this.props.TeamProjects;
                const allpros = projects.map(project => ({
                    value: project._id,
                    label: project.ProjectName
                }));

                this.setState({
                    projects: allpros
                });

                const teampro = projects
                    .filter(project => validPros.find(proId => proId === project._id))
                    .map(project => ({
                        value: project._id,
                        label: project.ProjectName
                    }));

                this.setState({
                    TeamProjects: teampro
                });
            })
            .catch(() =>
                toaster.notify(
                    'Network Request Error for Projects! Try again or check connection',
                    {
                        duration: 5000
                    }
                )
            );
    }

    handleLeadChange(value) {
        this.setState({
            TeamLead: value,
            changeInfo: true
        });
    }

    handleProChange(value) {
        this.setState({
            TeamProjects: value,
            changeInfo: true
        });
    }

    handleMemChange(value) {
        this.setState({
            TeamMembers: value,
            changeInfo: true
        });
    }

    handleSave(event) {
        event.preventDefault();

        let url = 'https://agile-river-17555.herokuapp.com/team/' + this.props.TeamId;
        axios({
            method: 'put',
            url: url,
            data: {
                TeamName: this.props.title,
                TeamLead: this.state.TeamLead.value,
                Projects: this.state.TeamProjects.map(project => project.value),
                Employees: this.state.TeamMembers.map(member => member.value)
            },
            config: { headers: { 'Content-type': 'application/json' } }
        })
            .then(res => {
                if (res.status === 200) console.log('Update Success');
            })
            .then(alert('Team: ' + this.props.title + ' has been updated'))
            .then(() => this.setState({ colorChange: true }))
            .catch(() => alert('Change failed'));
    }

    render() {
        return (
            <div className="panel panel-default fixed-panel">
                <div
                    className="panel-heading"
                    style={this.state.colorChange ? { background: '#fcd17b' } : null}
                >
                    <span className="panel-title">{this.props.title}</span>
                    <span>
                        {this.state.changeInfo ? (
                            <button
                                className="btn btn-primary pull-right"
                                onClick={this.handleSave}
                            >
                                SAVE
                            </button>
                        ) : (
                            <button
                                className="btn btn-primary pull-right"
                                onClick={this.handleSave}
                                disabled
                            >
                                SAVE
                            </button>
                        )}
                    </span>
                </div>
                <div className="panel-body">
                    <p>Team Lead</p>
                    <Select
                        onChange={this.handleLeadChange}
                        closeMenuOnSelect={false}
                        value={this.state.TeamLead}
                        className="SingleSelect"
                        options={this.state.employees}
                    />

                    <p>Team Members</p>
                    <Select
                        options={this.state.employees}
                        onChange={this.handleMemChange}
                        closeMenuOnSelect={false}
                        isMulti
                        className="MultiSelect"
                        value={this.state.TeamMembers}
                    />

                    <p>Projects</p>
                    <Select
                        onChange={this.handleProChange}
                        options={this.state.projects}
                        closeMenuOnSelect={false}
                        className="MultiSelect"
                        value={this.state.TeamProjects}
                        isMulti
                    />
                </div>
            </div>
        );
    }
}

export default Panel;
