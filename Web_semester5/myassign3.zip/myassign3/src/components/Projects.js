import React, { Component } from 'react';
import Navbar from './Navbar';
import axios from 'axios';
import toaster from 'toasted-notes';

class Projects extends Component {
    constructor() {
        super();
        this.state = {
            projects: []
        };
    }

    componentDidMount() {
        axios
            .get('https://agile-river-17555.herokuapp.com/projects')
            .then(res => {
                this.setState({
                    projects: res.data
                });
            })
            .catch(() =>
                toaster.notify(
                    'Network Request Error for projects! Try again or check connection',
                    {
                        duration: 5000
                    }
                )
            );
    }

    render() {
        return (
            <div>
                <Navbar title="Assignment3 - Projects Details"></Navbar>
                <table className="table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Project Name</th>
                            <th>Description</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.projects.map(project => {
                            return (
                                <tr key={project._id}>
                                    <td className="col-md-2">
                                        <b>{project.ProjectName}</b>
                                    </td>
                                    <td className="col-md-6">{project.ProjectDescription}</td>
                                    <td className="col-md-2">
                                        {project.ProjectStartDate
                                            ? project.ProjectStartDate
                                            : 'Unknown'}
                                    </td>
                                    <td className="col-md-2">
                                        {project.ProjectEndDate
                                            ? project.ProjectEndDate
                                            : 'Unknown'}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        );
    }
}

export default Projects;
