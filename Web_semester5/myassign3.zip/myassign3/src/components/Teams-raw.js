import React, { Component } from 'react';
import '../../src/App.css';
import Navbar from './Navbar';
import Panel from './Panel';
import axios from 'axios';
import toaster from 'toasted-notes';

class Teamsraw extends Component {
    constructor() {
        super();
        this.state = {
            Teams: []
        };
    }
    componentDidMount() {
        axios
            .get('https://agile-river-17555.herokuapp.com/teams-raw')
            .then(res => {
                const teams = res.data;
                this.setState({
                    Teams: teams
                });
            })
            .catch(() =>
                toaster.notify(
                    'Network Request Error for Teams-raw! Try again or check connection',
                    {
                        duration: 5000
                    }
                )
            );
    }

    render() {
        return (
            <div>
                <Navbar title="Assignment3 - Team Details" />
                <div className="container-fluid">
                    <div className="row">
                        {this.state.Teams.map(team => (
                            <div key={team._id} className="col-md-4">
                                <Panel
                                    title={team.TeamName}
                                    TeamLead={team.TeamLead}
                                    TeamId={team._id}
                                    TeamEmps={team.Employees}
                                    TeamProjects={team.Projects}
                                    button="Save"
                                ></Panel>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }
}

export default Teamsraw;
