import React, { Component } from 'react';
import Navbar from './Navbar';
import axios from 'axios';
import toaster from 'toasted-notes';

class Teams extends Component {
    constructor() {
        super();
        this.state = {
            teams: []
        };
    }

    componentDidMount() {
        axios
            .get('https://agile-river-17555.herokuapp.com/teams-raw')
            .then(res => {
                this.setState({
                    teams: res.data
                });
            })
            .catch(() =>
                toaster.notify('Network Request Error for Teams-raw! Try again', {
                    duration: 5000
                })
            );
    }

    render() {
        return (
            <div>
                <Navbar title="Assignment3 - All Teams Info"></Navbar>
                <div className="container-fluid">
                    <div className="row">
                        {this.state.teams.map(team => (
                            <div key={team._id} className="col-md-4">
                                <div className="panel panel-default fixed-panel">
                                    <div className="panel-heading">
                                        <span className="panel-title">
                                            {team.TeamName + ' - ID: ' + team._id}
                                        </span>
                                    </div>
                                    <div className="panel-body">
                                        <div>
                                            <p>
                                                <b>Team Lead ID: </b>
                                            </p>
                                            <p> {team.TeamLead}</p>
                                        </div>
                                        <div>
                                            <p>
                                                <b>Team Employees ID: </b>
                                            </p>
                                            {team.Employees.map(employee => (
                                                <p key={employee}>{employee}</p>
                                            ))}
                                        </div>
                                        <div>
                                            <p>
                                                <b>Team Projects ID: </b>
                                            </p>{' '}
                                            {team.Projects.map(project => (
                                                <p key={project}>{project}</p>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }
}

export default Teams;
